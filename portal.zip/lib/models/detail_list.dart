import 'package:flutter/material.dart';

class DetailItem extends StatelessWidget {
  final parameter, value;
  const DetailItem({Key? key, required this.parameter, required this.value})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 0.5,
                padding: EdgeInsets.all(10),
                child: Text(
                  parameter,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.5,
                child: Text(value),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
