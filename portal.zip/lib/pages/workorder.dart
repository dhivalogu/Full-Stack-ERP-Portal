import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import '../models/detail_list.dart';
import 'package:sweetalert/sweetalert.dart';
import 'notification.dart';
import 'package:bot_toast/bot_toast.dart';

var data = [];
var data1;

class OrderList extends StatefulWidget {
  const OrderList({Key? key}) : super(key: key);

  @override
  _OrderListState createState() => _OrderListState();
}

class _OrderListState extends State<OrderList> {
  @override
  Future<String> load() async {
    Response response = await post(
      Uri.parse("http://1b403ab0d864.ngrok.io/maintenance/olist"),
    );
    data = jsonDecode(response.body);

    print(data[0]);
    return "Success";
  }

  Widget build(BuildContext context) {
    return FutureBuilder<String>(
        future: load(),
        builder: (context, AsyncSnapshot<String> snapshot) {
          if (snapshot.hasData) {
            return Scaffold(
              appBar: AppBar(
                title: Text('Order List'),
              ),
              body: LayoutBuilder(
                builder: (context, constraints) => SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        alignment: Alignment.topLeft,
                        child: SingleChildScrollView(
                          child: ConstrainedBox(
                            constraints:
                                BoxConstraints(minWidth: constraints.minWidth),
                            child: DataTable(
                              columns: const <DataColumn>[
                                DataColumn(
                                  label: Text(
                                    'Type',
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ),
                                DataColumn(
                                  label: Text(
                                    'Equipment',
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ),
                                DataColumn(
                                  label: Text(
                                    '',
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ),
                              ],
                              rows: data
                                  .map(
                                    (e) => DataRow(
                                      cells: [
                                        DataCell(Text(e["ORDER_TYPE"][0])),
                                        DataCell(Text(e["EQUIDESCR"][0])),
                                        DataCell(
                                          FlatButton(
                                            color: Colors.blue,
                                            child: Text('View'),
                                            onPressed: () => Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => OrderView(
                                                    id: e["ORDERID"][0]),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                  .toList(),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          } else {
            return Scaffold(
              appBar: AppBar(
                title: Text('Order List'),
              ),
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
        });
  }
}

class OrderView extends StatelessWidget {
  final id;
  const OrderView({Key? key, required this.id}) : super(key: key);

  @override
  Future<String> load() async {
    Response response = await post(
      Uri.parse("http://1b403ab0d864.ngrok.io/maintenance/odetail"),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{'id': id}),
    );
    data1 = jsonDecode(response.body);
    print(data1);
    print(data1.runtimeType);
    return "Success";
  }

  Widget build(BuildContext context) {
    return FutureBuilder<String>(
        future: load(),
        builder: (context, AsyncSnapshot<String> snapshot) {
          if (snapshot.hasData) {
            return Scaffold(
                appBar: AppBar(
                  title: Text('View Order'),
                  actions: [
                    FlatButton(
                        color: Colors.white,
                        child: Text('Edit'),
                        onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => OrderEdit(
                                  notifNo: data1["NOTIF_NO"][0],
                                  priority: data1["PRIORITY"][0],
                                  equipment: data1["EQUIPMENT"][0],
                                  orderNo: data1["ORDERID"][0],
                                  orderType: data1["ORDER_TYPE"][0],
                                  shortText: data1["SHORT_TEXT"][0],
                                ),
                              ),
                            )),
                  ],
                ),
                body: ListView(
                  padding: const EdgeInsets.all(8),
                  children: <Widget>[
                    DetailItem(
                      parameter: 'Order ID',
                      value: data1["ORDERID"][0],
                    ),
                    DetailItem(
                      parameter: 'Order Type',
                      value: data1["ORDER_TYPE"][0],
                    ),
                    DetailItem(
                      parameter: 'Priority',
                      value: data1["PRIORITY"][0],
                    ),
                    DetailItem(
                      parameter: 'Equipment No',
                      value: data1["EQUIPMENT"][0],
                    ),
                    DetailItem(
                      parameter: 'Description',
                      value: data1["SHORT_TEXT"][0],
                    ),
                    DetailItem(
                      parameter: 'Functional Location',
                      value: data1["FUNCT_LOC"][0],
                    ),
                    DetailItem(
                      parameter: 'Status',
                      value: data1["SYS_STATUS"][0],
                    ),
                    DetailItem(
                      parameter: 'Estimated Cost',
                      value: data1["ESTIMATED_COSTS"][0],
                    ),
                    Container(
                      height: 50,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width * 0.5,
                                padding: EdgeInsets.all(10),
                                child: Text(
                                  "Notification No",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              InkWell(
                                splashColor: data1["NOTIF_NO"][0] != ''
                                    ? Colors.blue.withAlpha(30)
                                    : Colors.white,
                                onTap: () {
                                  if (data1["NOTIF_NO"][0] != '')
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => NotificationView(
                                            id: data1["NOTIF_NO"][0]),
                                      ),
                                    );
                                },
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.5,
                                  child: Text(data1["NOTIF_NO"][0]),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                    DetailItem(
                      parameter: 'Start Date',
                      value: data1["START_DATE"][0],
                    ),
                    DetailItem(
                      parameter: 'Finish Date',
                      value: data1["FINISH_DATE"][0],
                    ),
                    DetailItem(
                      parameter: 'Cost Centre',
                      value: data1["COSTCENTER"][0],
                    ),
                    DetailItem(
                      parameter: 'Maintenance Plant',
                      value: data1["MAINTPLANT"][0],
                    ),
                    DetailItem(
                      parameter: 'Functional Location',
                      value: data1["FUNCT_LOC"][0],
                    ),
                    DetailItem(
                      parameter: 'Work Center',
                      value: data1["MN_WK_CTR"][0],
                    ),
                  ],
                ));
          } else {
            return Scaffold(
              appBar: AppBar(
                title: Text('View Workorder'),
              ),
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
        });
  }
}

class OrderCreate extends StatefulWidget {
  final notifNo;
  const OrderCreate({Key? key, required this.notifNo}) : super(key: key);

  @override
  _OrderCreateState createState() => _OrderCreateState(this.notifNo);
}

class _OrderCreateState extends State<OrderCreate> {
  _OrderCreateState(notifNo) {
    this.NOTIFNO1.text = notifNo;
  }
  int backgroundColor = 0x42000000;
  int seconds = 10;
  bool clickClose = false;
  bool allowClick = false;
  bool crossPage = true;
  int animationMilliseconds = 200;
  int animationReverseMilliseconds = 200;
  BackButtonBehavior backButtonBehavior = BackButtonBehavior.none;
  final DURATION_NORMAL = TextEditingController();
  final EQUIPMENT = TextEditingController();
  final PRIORITY = TextEditingController();
  String ORDER_TYPE = 'PM01';
  final WORK_ACTIVITY = TextEditingController();
  final shortText = TextEditingController();
  var NOTIFNO1 = TextEditingController();

  var responseText = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('Create Work Order'),
      ),
      body: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        child: Center(
          child: Padding(
            padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
            child: Column(
              children: [
                TextFormField(
                  readOnly: NOTIFNO1.text == '' ? false : true,
                  controller: NOTIFNO1,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Notification Number',
                  ),
                ),
                Row(
                  children: [
                    Text("Order Type"),
                    Padding(padding: EdgeInsets.all(15)),
                    DropdownButton<String>(
                      value: ORDER_TYPE,
                      icon: const Icon(Icons.expand_more),
                      iconSize: 24,
                      elevation: 16,
                      style: const TextStyle(color: Colors.blue),
                      underline: Container(
                        height: 2,
                        width: 20,
                        color: Colors.black,
                      ),
                      onChanged: (String? newValue) {
                        setState(() {
                          ORDER_TYPE = newValue!;
                        });
                      },
                      items: <String>['PM01', 'PM02', 'PM03']
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                    )
                  ],
                ),
                TextFormField(
                  controller: EQUIPMENT,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Equipment',
                  ),
                ),
                TextFormField(
                  controller: PRIORITY,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Priority',
                  ),
                ),
                TextFormField(
                  controller: shortText,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Description',
                  ),
                ),
                TextFormField(
                  controller: DURATION_NORMAL,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Duration',
                  ),
                ),
                TextFormField(
                  controller: WORK_ACTIVITY,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Work Activity',
                  ),
                ),
                ElevatedButton(
                  child: Text('Create'),
                  onPressed: () async {
                    BotToast.showLoading(
                        clickClose: clickClose,
                        allowClick: allowClick,
                        crossPage: crossPage,
                        backButtonBehavior: backButtonBehavior,
                        animationDuration:
                            Duration(milliseconds: animationMilliseconds),
                        animationReverseDuration: Duration(
                            milliseconds: animationReverseMilliseconds),
                        duration: Duration(
                          seconds: seconds,
                        ),
                        backgroundColor: Color(backgroundColor));
                    Response response = await post(
                        Uri.parse(
                            "http://1b403ab0d864.ngrok.io/maintenance/ocreate"),
                        headers: <String, String>{
                          'Content-Type': 'application/json; charset=UTF-8',
                        },
                        body: jsonEncode(<String, String>{
                          'NOTIF_NO': NOTIFNO1.text,
                          'ORDER_TYPE': ORDER_TYPE,
                          'EQUIPMENT': EQUIPMENT.text,
                          'PRIORITY1': PRIORITY.text,
                          'DURATION_NORMAL': DURATION_NORMAL.text,
                          'WORK_ACTIVITY': WORK_ACTIVITY.text,
                          'shortText': shortText.text,
                        }));
                    print(response.body);

                    if (response.body != '') {
                      BotToast.closeAllLoading();
                      setState(() {
                        responseText = 'Work Order Created :' + response.body;
                      });
                      showDialog<String>(
                        context: context,
                        builder: (BuildContext context) => AlertDialog(
                          title: const Text('Work Order Created Succesfully'),
                          content: Text(response.body),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () => Navigator.pop(context, 'OK'),
                              child: const Text('OK'),
                            ),
                          ],
                        ),
                      );
                    } else {
                      BotToast.closeAllLoading();
                      setState(() {
                        responseText =
                            'Work Order Not Created,Please Enter Valid Details';
                      });
                    }
                  },
                ),
                Text(responseText),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class OrderEdit extends StatefulWidget {
  final notifNo;
  final priority;
  final orderType;
  final equipment;
  final shortText;
  final orderNo;
  const OrderEdit(
      {Key? key,
      this.notifNo,
      this.priority,
      this.equipment,
      this.orderNo,
      this.orderType,
      this.shortText})
      : super(key: key);

  @override
  _OrderEditState createState() => _OrderEditState(this.notifNo, this.priority,
      this.equipment, this.orderNo, this.orderType, this.shortText);
}

class _OrderEditState extends State<OrderEdit> {
  _OrderEditState(notifNo, priority, equipment, orderNo, orderType, shortText) {
    this.NOTIFNO1.text = notifNo;
    this.PRIORITY.text = priority;
    this.EQUIPMENT.text = equipment;
    this.order_no.text = orderNo;
    this.ORDER_TYPE.text = orderType;
    this.shortText.text = shortText;
  }

  final DURATION_NORMAL = TextEditingController();
  final EQUIPMENT = TextEditingController();
  final PRIORITY = TextEditingController();
  final ORDER_TYPE = TextEditingController();
  final order_no = TextEditingController();
  final shortText = TextEditingController();
  var NOTIFNO1 = TextEditingController();
  var responseText = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('Edit Work Order'),
      ),
      body: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        child: Center(
          child: Padding(
            padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
            child: Column(
              children: [
                TextFormField(
                  readOnly: true,
                  controller: order_no,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Order ID',
                  ),
                ),
                TextFormField(
                  controller: NOTIFNO1,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Notification Number',
                  ),
                ),
                TextFormField(
                  controller: ORDER_TYPE,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Order Type',
                  ),
                ),
                TextFormField(
                  controller: EQUIPMENT,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Equipment',
                  ),
                ),
                TextFormField(
                  controller: PRIORITY,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Priority',
                  ),
                ),
                TextFormField(
                  controller: shortText,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Description',
                  ),
                ),
                TextFormField(
                  controller: DURATION_NORMAL,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Duration',
                  ),
                ),
                ElevatedButton(
                  child: Text('Update'),
                  onPressed: () async {
                    Response response = await post(
                        Uri.parse(
                            "http://1b403ab0d864.ngrok.io/maintenance/oedit"),
                        headers: <String, String>{
                          'Content-Type': 'application/json; charset=UTF-8',
                        },
                        body: jsonEncode(<String, String>{
                          'NOTIF_NO': NOTIFNO1.text,
                          'ORDER_TYPE': ORDER_TYPE.text,
                          'EQUIPMENT': EQUIPMENT.text,
                          'PRIORITY1': PRIORITY.text,
                          'DURATION_NORMAL': DURATION_NORMAL.text,
                          'order_no': order_no.text,
                          'shortText': shortText.text,
                        }));
                    print(response.body);

                    if (response.body != '') {
                      setState(() {
                        responseText = 'Work Order Edited :' + response.body;
                      });
                      SweetAlert.show(
                        context,
                        title: "Work Order Edited Succesfully",
                        subtitle: response.body,
                        style: SweetAlertStyle.success,
                      );
                    } else {
                      setState(() {
                        responseText =
                            'Work Order Not Updated,Please Enter Valid Details';
                      });
                      SweetAlert.show(
                        context,
                        title: "Work Order Not Updated",
                        subtitle: "Please Enter Valid Details",
                        style: SweetAlertStyle.error,
                      );
                    }
                  },
                ),
                Text(responseText),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ViewOrder extends StatelessWidget {
  final idController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("View Work Order"),
      ),
      body: Center(
        child: Container(
          width: 200,
          height: 250,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextFormField(
                controller: idController,
                decoration: InputDecoration(
                  labelText: 'Order ID',
                  border: OutlineInputBorder(),
                ),
                onFieldSubmitted: (value) => idController.text = value,
              ),
              ElevatedButton(
                child: Text('View'),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => OrderView(id: idController.text),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
