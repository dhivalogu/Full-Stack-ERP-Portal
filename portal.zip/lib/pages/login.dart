import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:portal/pages/notification.dart';
import 'package:portal/pages/workorder.dart';
import 'dart:math';
import 'package:bot_toast/bot_toast.dart';
import 'package:sweetalert/sweetalert.dart';
import 'package:loading_animations/loading_animations.dart';

class SecondRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        title: Text('Dashboard'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushReplacementNamed(context, "/login"),
        child: const Icon(Icons.logout),
        backgroundColor: Colors.red,
      ),
      body: GridView(
        padding: EdgeInsets.all(15),
        children: <Widget>[
          Card(
            semanticContainer: true,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => NotificationList(),
                ),
              ),
              child: Stack(
                children: [
                  Image.asset('assets/notifications.jpg', fit: BoxFit.fill),
                  Positioned(
                    child: Container(
                      // We use this Container to create a black box that wraps the white text so that the user can read the text even when the image is white
                      color: Colors.black54,
                      padding: EdgeInsets.fromLTRB(40, 45, 40, 45),
                      child: Text(
                        'Notifications',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 10,
            margin: EdgeInsets.all(5),
          ),
          Card(
            semanticContainer: true,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => OrderList(),
                ),
              ),
              child: Stack(
                children: [
                  Image.asset('assets/workorder.png', fit: BoxFit.fill),
                  Positioned(
                    child: Container(
                      // We use this Container to create a black box that wraps the white text so that the user can read the text even when the image is white
                      color: Colors.black54,
                      padding: EdgeInsets.fromLTRB(44.5, 45, 44.5, 45),
                      child: Text(
                        'Work Order',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 5,
            margin: EdgeInsets.all(5),
          ),
          Card(
            semanticContainer: true,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => NotificationCreate(),
                ),
              ),
              child: Stack(
                children: [
                  Image.asset('assets/notifications.jpg', fit: BoxFit.fill),
                  Positioned(
                    child: Container(
                      // We use this Container to create a black box that wraps the white text so that the user can read the text even when the image is white
                      color: Colors.black54,
                      padding: EdgeInsets.fromLTRB(42, 36, 42, 36),
                      child: Text(
                        'Create Notification',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 5,
            margin: EdgeInsets.all(5),
          ),
          Card(
            semanticContainer: true,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => OrderCreate(
                    notifNo: '',
                  ),
                ),
              ),
              child: Stack(
                children: [
                  Image.asset('assets/workorder.png', fit: BoxFit.fill),
                  Positioned(
                    child: Container(
                      // We use this Container to create a black box that wraps the white text so that the user can read the text even when the image is white
                      color: Colors.black54,
                      padding: EdgeInsets.fromLTRB(42, 37, 42, 37),
                      child: Text(
                        'Create Work Order',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 5,
            margin: EdgeInsets.all(5),
          ),
          Card(
            semanticContainer: true,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ViewNotification(),
                ),
              ),
              child: Stack(
                children: [
                  Image.asset('assets/notifications.jpg', fit: BoxFit.fill),
                  Positioned(
                    child: Container(
                      // We use this Container to create a black box that wraps the white text so that the user can read the text even when the image is white
                      color: Colors.black54,
                      padding: EdgeInsets.fromLTRB(42, 37, 42, 37),
                      child: Text(
                        'View Notification',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 5,
            margin: EdgeInsets.all(5),
          ),
          Card(
            semanticContainer: true,
            clipBehavior: Clip.antiAliasWithSaveLayer,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ViewOrder(),
                ),
              ),
              child: Stack(
                children: [
                  Image.asset('assets/workorder.png', fit: BoxFit.fill),
                  Positioned(
                    child: Container(
                      // We use this Container to create a black box that wraps the white text so that the user can read the text even when the image is white
                      color: Colors.black54,
                      padding: EdgeInsets.fromLTRB(42, 37, 42, 37),
                      child: Text(
                        'View Work Order',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            elevation: 5,
            margin: EdgeInsets.all(5),
          ),
        ],
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          childAspectRatio: 3 / 2,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  int backgroundColor = 0x42000000;
  int seconds = 10;
  bool clickClose = false;
  bool allowClick = false;
  bool crossPage = true;
  int animationMilliseconds = 200;
  int animationReverseMilliseconds = 200;
  BackButtonBehavior backButtonBehavior = BackButtonBehavior.none;
  final idController = TextEditingController();

  final passController = TextEditingController();
  var mainColor = Color(0XFF0088FF);

  @override
  Widget build(BuildContext context) {
    var halfSide = MediaQuery.of(context).size.width / 2;
    var side = halfSide * sqrt(2);

    var _borders = OutlineInputBorder(
        borderSide: BorderSide(
          color: Colors.white,
          width: 1.5,
        ),
        borderRadius: BorderRadius.circular(32));

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: <Widget>[
          Positioned.fill(
            child: Container(
              color: Colors.white,
            ),
          ),
          Image.asset(
            'assets/bg.jpg',
            height: MediaQuery.of(context).size.height * 0.55,
            width: MediaQuery.of(context).size.width,
            fit: BoxFit.fitHeight,
          ),
          Align(
            alignment: Alignment(0, 0.25),
            child: Transform.rotate(
              angle: pi / 4,
              child: Material(
                elevation: 10,
                shadowColor: Colors.black,
                color: mainColor,
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  height: side,
                  width: side,
                  child: Transform.rotate(
                    angle: -pi / 4,
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'Login',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 20,
                            ),
                          ),
                          SizedBox(height: 16),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.5,
                            child: TextField(
                              keyboardType: TextInputType.emailAddress,
                              style: TextStyle(
                                color: Colors.white,
                              ),
                              controller: idController,
                              decoration: InputDecoration(
                                filled: false,
                                contentPadding: EdgeInsets.all(10),
                                enabledBorder: _borders,
                                focusedBorder: _borders,
                                hintText: 'Employee ID',
                                hintStyle: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 16),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.5,
                            child: TextField(
                              keyboardType: TextInputType.visiblePassword,
                              obscureText: true,
                              style: TextStyle(
                                color: Colors.white,
                              ),
                              controller: passController,
                              decoration: InputDecoration(
                                filled: false,
                                contentPadding: EdgeInsets.all(10),
                                enabledBorder: _borders,
                                focusedBorder: _borders,
                                hintText: 'Password',
                                hintStyle: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 12),
                          FloatingActionButton(
                            onPressed: () async {
                              print("Started");
                              BotToast.showLoading(
                                  clickClose: clickClose,
                                  allowClick: allowClick,
                                  crossPage: crossPage,
                                  backButtonBehavior: backButtonBehavior,
                                  animationDuration: Duration(
                                      milliseconds: animationMilliseconds),
                                  animationReverseDuration: Duration(
                                      milliseconds:
                                          animationReverseMilliseconds),
                                  duration: Duration(
                                    seconds: seconds,
                                  ),
                                  backgroundColor: Color(backgroundColor));

                              Response response = await post(
                                  Uri.parse(
                                      "http://1b403ab0d864.ngrok.io/employee/login"),
                                  headers: <String, String>{
                                    'Content-Type':
                                        'application/json; charset=UTF-8',
                                  },
                                  body: jsonEncode(<String, String>{
                                    'user_id': idController.text,
                                    'pass': passController.text
                                  }));
                              print(response.body);
                              if (response.body == '1') {
                                BotToast.closeAllLoading();
                                Navigator.pushReplacementNamed(
                                    context, "/dashboard");
                              } else {
                                BotToast.closeAllLoading();
                                SweetAlert.show(
                                  context,
                                  subtitle: "Please Enter Valid Credentials",
                                  style: SweetAlertStyle.error,
                                );
                              }
                            },
                            backgroundColor: Colors.white,
                            child: Icon(
                              Icons.login,
                              color: mainColor,
                              size: 40,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text(
                'm-Portal',
                style: TextStyle(
                  color: mainColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
