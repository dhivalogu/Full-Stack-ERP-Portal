import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import '../models/detail_list.dart';
import 'package:sweetalert/sweetalert.dart';
import 'package:bot_toast/bot_toast.dart';
import 'workorder.dart';

var data = [];
var data1;

class NotificationList extends StatefulWidget {
  const NotificationList({Key? key}) : super(key: key);

  @override
  _NotificationListState createState() => _NotificationListState();
}

class _NotificationListState extends State<NotificationList> {
  @override
  Future<String> load() async {
    Response response = await post(
      Uri.parse("http://1b403ab0d864.ngrok.io/maintenance/nlist"),
    );
    data = jsonDecode(response.body);

    print(data[0]);
    print(ObjectKey(data1));
    return "Success";
  }

  Widget build(BuildContext context) {
    return FutureBuilder<String>(
        future: load(),
        builder: (context, AsyncSnapshot<String> snapshot) {
          if (snapshot.hasData) {
            return Scaffold(
              appBar: AppBar(
                title: Text('Notification List'),
              ),
              body: LayoutBuilder(
                builder: (context, constraints) => SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        alignment: Alignment.topLeft,
                        child: SingleChildScrollView(
                          child: ConstrainedBox(
                            constraints:
                                BoxConstraints(minWidth: constraints.minWidth),
                            child: DataTable(
                              sortColumnIndex: 0,
                              sortAscending: true,
                              columns: const <DataColumn>[
                                DataColumn(
                                  label: Text(
                                    'Priority',
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ),
                                DataColumn(
                                  label: Text(
                                    'Equipment',
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ),
                                DataColumn(
                                  label: Text(
                                    '',
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ),
                              ],
                              rows: data
                                  .map(
                                    (e) => DataRow(
                                      cells: [
                                        DataCell(Text(e["PRIORITY"][0])),
                                        DataCell(Text(e["EQUIDESCR"][0])),
                                        DataCell(
                                          FlatButton(
                                            child: Icon(Icons.visibility),
                                            onPressed: () => Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    NotificationView(
                                                        id: e["NOTIFICAT"][0]),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                  .toList(),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          } else {
            return Scaffold(
              appBar: AppBar(
                title: Text('Notification List'),
              ),
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
        });
  }
}

class NotificationView extends StatelessWidget {
  final id;
  const NotificationView({Key? key, required this.id}) : super(key: key);

  @override
  Future<String> load() async {
    Response response = await post(
      Uri.parse("http://1b403ab0d864.ngrok.io/maintenance/nview"),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{'id': id}),
    );
    data1 = jsonDecode(response.body);
    print(data1);
    print(data1.runtimeType);
    return "Success";
  }

  Widget build(BuildContext context) {
    return FutureBuilder<String>(
        future: load(),
        builder: (context, AsyncSnapshot<String> snapshot) {
          if (snapshot.hasData) {
            return Scaffold(
                appBar: AppBar(
                  title: Text('View Notification'),
                  actions: [
                    FlatButton(
                        color: Colors.white,
                        child: Text('Edit'),
                        onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => NotificationEdit(
                                        equipment: data1["Equipment No"][0],
                                        notifNo: data1["Notification No"][0],
                                        notifType: data1["Notification Type"]
                                            [0],
                                        plant:
                                            data1["Maintenance Planning Plant"]
                                                [0],
                                        priority: data1["Priority"][0],
                                        shortText: data1["Short Text"][0],
                                        orderId: data1["Order ID"][0],
                                      )),
                            )),
                  ],
                ),
                body: ListView(
                  padding: const EdgeInsets.all(8),
                  children: <Widget>[
                    DetailItem(
                      parameter: 'Notification No',
                      value: data1["Notification No"][0],
                    ),
                    DetailItem(
                      parameter: 'Maintenance Planning Plant',
                      value: data1["Maintenance Planning Plant"][0],
                    ),
                    DetailItem(
                      parameter: 'Equipment No',
                      value: data1["Equipment No"][0],
                    ),
                    DetailItem(
                      parameter: 'Equipment',
                      value: data1["Equipment"][0],
                    ),
                    DetailItem(
                      parameter: 'Description',
                      value: data1["Short Text"][0],
                    ),
                    DetailItem(
                      parameter: 'Notification Type',
                      value: data1["Notification Type"][0],
                    ),
                    DetailItem(
                      parameter: 'Priority Type',
                      value: data1["Priority Type"][0],
                    ),
                    DetailItem(
                      parameter: 'Priority',
                      value: data1["Priority"][0],
                    ),
                    DetailItem(
                      parameter: 'Notification Date',
                      value: data1["Notification Date"][0],
                    ),
                    DetailItem(
                      parameter: 'Required End Date',
                      value: data1["Required End Date"][0],
                    ),
                    Container(
                      height: 50,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width * 0.5,
                                padding: EdgeInsets.all(10),
                                child: Text(
                                  "Order ID",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                              InkWell(
                                  splashColor: data1["Order ID"][0] != ''
                                      ? Colors.blue.withAlpha(30)
                                      : Colors.white,
                                  onTap: () {
                                    if (data1["Order ID"][0] != '')
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => OrderView(
                                              id: data1["Order ID"][0]),
                                        ),
                                      );
                                  },
                                  child: data1["Order ID"][0] != ''
                                      ? Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.5,
                                          child: Text(data1["Order ID"][0]),
                                        )
                                      : Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.1,
                                          child: IconButton(
                                            color: Colors.blue,
                                            onPressed: () => Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => OrderCreate(
                                                    notifNo:
                                                        data1["Notification No"]
                                                            [0]),
                                              ),
                                            ),
                                            icon: Icon(Icons.create),
                                          ) /*FlatButton(
                                              color: Colors.white,
                                              child: Text('Create'),
                                              onPressed: () => Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (context) =>
                                                          OrderCreate(
                                                              notifNo: data1[
                                                                      "Notification No"]
                                                                  [0]),
                                                    ),
                                                  ),),*/
                                          ))
                            ],
                          ),
                        ],
                      ),
                    ),
                    DetailItem(
                      parameter: 'Maintenance Plant',
                      value: data1["Maintenance Plant"][0],
                    ),
                    DetailItem(
                      parameter: 'Functional Location',
                      value: data1["Functional Location"][0],
                    ),
                    DetailItem(
                      parameter: 'Work Center',
                      value: data1["Work Center"][0],
                    ),
                  ],
                ));
          } else {
            return Scaffold(
              appBar: AppBar(
                title: Text('Notification View'),
              ),
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
        });
  }
}

class NotificationCreate extends StatefulWidget {
  const NotificationCreate({Key? key}) : super(key: key);

  @override
  _NotificationCreateState createState() => _NotificationCreateState();
}

class _NotificationCreateState extends State<NotificationCreate> {
  int backgroundColor = 0x42000000;
  int seconds = 10;
  bool clickClose = false;
  bool allowClick = false;
  bool crossPage = true;
  int animationMilliseconds = 200;
  int animationReverseMilliseconds = 200;
  BackButtonBehavior backButtonBehavior = BackButtonBehavior.none;
  String notifType = 'B1';
  final equipment = TextEditingController();
  final priority = TextEditingController();
  final plant = TextEditingController();
  final plantGroup = TextEditingController();
  final reportedBy = TextEditingController();
  final shortText = TextEditingController();
  var responseText = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('Create Notification'),
      ),
      body: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        child: Center(
          child: Padding(
            padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
            child: Column(
              children: [
                Row(
                  children: [
                    Text("Notification Type"),
                    Padding(padding: EdgeInsets.all(15)),
                    DropdownButton<String>(
                      value: notifType,
                      icon: const Icon(Icons.expand_more),
                      iconSize: 24,
                      elevation: 16,
                      style: const TextStyle(color: Colors.blue),
                      underline: Container(
                        height: 2,
                        width: 20,
                        color: Colors.black,
                      ),
                      onChanged: (String? newValue) {
                        setState(() {
                          notifType = newValue!;
                        });
                      },
                      items: <String>[
                        'B1',
                        'B2',
                        'B3',
                        'CM',
                        'I1',
                        'M1',
                        'M2',
                        'M3',
                        'OS',
                        'R1',
                        'SN',
                        'Y1',
                        'Y2',
                        'Z1',
                        'Z2',
                        'ZA'
                      ].map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                    )
                  ],
                ),
                TextFormField(
                  controller: plant,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Plant',
                  ),
                ),
                TextFormField(
                  controller: plantGroup,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Plant Group',
                  ),
                ),
                TextFormField(
                  controller: equipment,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Equipment',
                  ),
                ),
                TextFormField(
                  controller: priority,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Priority',
                  ),
                ),
                TextFormField(
                  controller: shortText,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Description',
                  ),
                ),
                TextFormField(
                  controller: reportedBy,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Reported By',
                  ),
                ),
                ElevatedButton(
                  child: Text('Create'),
                  onPressed: () async {
                    BotToast.showLoading(
                        clickClose: clickClose,
                        allowClick: allowClick,
                        crossPage: crossPage,
                        backButtonBehavior: backButtonBehavior,
                        animationDuration:
                            Duration(milliseconds: animationMilliseconds),
                        animationReverseDuration: Duration(
                            milliseconds: animationReverseMilliseconds),
                        duration: Duration(
                          seconds: seconds,
                        ),
                        backgroundColor: Color(backgroundColor));
                    Response response = await post(
                        Uri.parse(
                            "http://1b403ab0d864.ngrok.io/maintenance/ncreate"),
                        headers: <String, String>{
                          'Content-Type': 'application/json; charset=UTF-8',
                        },
                        body: jsonEncode(<String, String>{
                          'notifType': notifType,
                          'equipment': equipment.text,
                          'priority': priority.text,
                          'plant': plant.text,
                          'plantGroup': plantGroup.text,
                          'reportedBy': reportedBy.text,
                          'shortText': shortText.text,
                        }));
                    if (response.body == '') {
                      BotToast.closeAllLoading();
                      SweetAlert.show(
                        context,
                        title: "Notification Not Created",
                        subtitle: "Please Enter Valid Details",
                        style: SweetAlertStyle.error,
                        confirmButtonText: "Retry",
                      );
                    } else {
                      BotToast.closeAllLoading();
                      SweetAlert.show(
                        context,
                        title: "Notification Created Succesfully",
                        subtitle: response.body,
                        style: SweetAlertStyle.success,
                        confirmButtonText: "Create Order",
                        onPress: (isConfirm) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => OrderCreate(
                                      notifNo: response.body,
                                    )),
                          );
                          return false;
                        },
                      );
                    }
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class NotificationEdit extends StatefulWidget {
  final notifType;
  final equipment;
  final priority;
  final plant;
  final shortText;
  final notifNo;
  final orderId;
  const NotificationEdit(
      {Key? key,
      this.notifNo,
      this.equipment,
      this.notifType,
      this.plant,
      this.priority,
      this.shortText,
      this.orderId})
      : super(key: key);

  @override
  _NotificationEditState createState() => _NotificationEditState(
      this.notifNo,
      this.equipment,
      this.notifType,
      this.plant,
      this.priority,
      this.shortText,
      this.orderId);
}

class _NotificationEditState extends State<NotificationEdit> {
  _NotificationEditState(
      notifNo, equipment, notifType, plant, priority, shortText, orderId) {
    this.equipment.text = equipment;
    this.notifNo.text = notifNo;
    this.notifType.text = notifType;
    this.plant.text = plant;
    this.priority.text = priority;
    this.shortText.text = shortText;
    this.orderId.text = orderId;
  }
  final notifType = TextEditingController();
  final equipment = TextEditingController();
  final priority = TextEditingController();
  final plant = TextEditingController();
  final notifNo = TextEditingController();
  final shortText = TextEditingController();
  final orderId = TextEditingController();
  var responseText = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('Edit Notification'),
      ),
      body: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        child: Center(
          child: Padding(
            padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
            child: Column(
              children: [
                TextFormField(
                  readOnly: true,
                  controller: notifNo,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Notification Number',
                  ),
                ),
                TextFormField(
                  controller: notifType,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Notification Type',
                  ),
                ),
                TextFormField(
                  controller: equipment,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Equipment',
                  ),
                ),
                TextFormField(
                  controller: plant,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Plant',
                  ),
                ),
                TextFormField(
                  controller: priority,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Priority',
                  ),
                ),
                TextFormField(
                  controller: shortText,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Description',
                  ),
                ),
                ElevatedButton(
                  child: Text('Update'),
                  onPressed: () async {
                    Response response = await post(
                        Uri.parse(
                            "http://1b403ab0d864.ngrok.io/maintenance/nedit"),
                        headers: <String, String>{
                          'Content-Type': 'application/json; charset=UTF-8',
                        },
                        body: jsonEncode(<String, String>{
                          'notifNo': notifNo.text,
                          'notifType': notifType.text,
                          'equipment': equipment.text,
                          'priority': priority.text,
                          'plant': plant.text,
                          'shortText': shortText.text,
                        }));
                    print(response.body);

                    if (response.body != '') {
                      setState(() {
                        responseText = 'Notification Edited :' + response.body;
                      });
                      SweetAlert.show(
                        context,
                        title: "Notification Edited Succesfully",
                        subtitle: response.body,
                        style: SweetAlertStyle.success,
                      );
                    } else {
                      setState(() {
                        responseText =
                            'Notification Not Updated,Please Enter Valid Details';
                      });
                      SweetAlert.show(
                        context,
                        title: "Work Order Not Updated",
                        subtitle: "Please Enter Valid Details",
                        style: SweetAlertStyle.error,
                      );
                    }
                  },
                ),
                Text(responseText),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ViewNotification extends StatelessWidget {
  final idController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("View Notification"),
      ),
      body: Center(
        child: Container(
          width: 200,
          height: 250,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextFormField(
                controller: idController,
                decoration: InputDecoration(
                  labelText: 'Notification No',
                  border: OutlineInputBorder(),
                ),
                onFieldSubmitted: (value) => idController.text = value,
              ),
              ElevatedButton(
                child: Text('View'),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        NotificationView(id: idController.text),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NDashBoard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        title: Text('Dashboard'),
        actions: [
          FlatButton(
            color: Colors.red,
            child: Text('Log Out'),
            onPressed: () => Navigator.pushReplacementNamed(context, "/login"),
          ),
        ],
      ),
      body: GridView(
        padding: EdgeInsets.all(15),
        children: <Widget>[
          Card(
            color: Colors.blue,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.pushNamed(context, 'list'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "Notification List",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            elevation: 20,
          ),
          Card(
            color: Colors.blue,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.pushNamed(context, 'create'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "Create Notification",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        decorationStyle: TextDecorationStyle.double),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            elevation: 20,
          ),
          Card(
            color: Colors.blue,
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.pushNamed(context, 'view'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "View Notification",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            elevation: 20,
          ),
        ],
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          childAspectRatio: 3 / 2,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
        ),
      ),
    );
  }
}
